/*

*/
const num1 = 1.0
console.log(typeof num1)
const num2 = 1.1
console.log(typeof num2)
console.log(Number.isInteger(num1))//retorna TRUE
console.log(Number.isInteger(num2))//FALSE