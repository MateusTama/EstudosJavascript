/*
Resultados de operadores lógicos ou relacionais são sempre boeleanos.
Ou true, ou false.
https://www.w3schools.com/js/js_comparisons.asp
==
===
!=
!==
>
<
>=
<=
*/
console.log("'1'==1",('1'==1));//true
console.log("'1'===1", ('1'===1));//false
console.log("'1'!=1",('1'!=1));//false
console.log("'1'!==1", ('1'!==1));//true
console.log('null==undefined',null==undefined);     
console.log('null===undefined',null===undefined);
console.log('typeof null',typeof null);
console.log('typeof undefined',typeof undefined);


