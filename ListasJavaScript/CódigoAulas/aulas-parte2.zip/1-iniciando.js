//quantas sentenças serão executadas?
console.log('1,2,3 testando ...')
//console.log('1,2,3 testando ...') console.log('1,2,3 testando ...') 
console.log('1,2,3 testando ...');
 console.log('1,2,3 testando ...'); 
console.log('1,2,3 testando, uhul ...')