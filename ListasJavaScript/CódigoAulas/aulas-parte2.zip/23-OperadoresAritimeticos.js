//exemplo de criação de quatro variáveis em uma linha, com destructuring
const [a,b,c,d] = [7,8,5,6]
/*
+
-
/
*
--
++
** (potencia)
%
+=
-=
*=
%=
OBS.: Em expressões numéricas, utilize sempre parênteses, pois
Multiplication (*) and division (/) have higher precedence than addition (+) and subtraction (-).
Fonte: https://www.w3schools.com/js/js_arithmetic.asp
*/
let x=10
let y = 11
console.log(--y===x++);//true ou false?