let x = 10
let y = 2


x+= 5
console.log('x+=',x);
x+= y
console.log('x+=y',x);
y*=2
console.log('y*=2',y);
y/=2
console.log('y/=2',y);
x/=y
console.log('x/=y',x);
y%=y
console.log('y%=y',y);


