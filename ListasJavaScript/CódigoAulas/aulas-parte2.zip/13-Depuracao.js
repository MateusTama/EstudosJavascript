//depurando código
/* Basta adicionar um breakpoint, abrir o terminal de depuração, 
e executar o código naquela terminal. */
let teste = 3
console.log(teste);
//agora, depuração condicional
teste = 2
console.log(teste)
