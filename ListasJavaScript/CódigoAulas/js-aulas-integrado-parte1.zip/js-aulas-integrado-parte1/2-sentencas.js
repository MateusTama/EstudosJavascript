/*
console.log('Oi'+1)
console.log(`'1'+1`,'1'+1)//11
console.log(`'1'-1`, '1'-1)//0
console.log(99+1)//soma
console.log(`99+'1'`, (99+'1'))//concatena
console.log(99.7)
console.log('7.5+1',7.5+1)
console.log(7.5+'1')//concatena:7.51
*/
/*Comentário em bloco  :
Use para escrever várias linhas para explicar
o código, documentar. Este bloco não será executado
  */
//blocos de código
const numero = 1%2;
if(numero==0)
{
    console.log(numero + ' é par')
}
else
{
    console.log(numero + ' é ímpar')
}

